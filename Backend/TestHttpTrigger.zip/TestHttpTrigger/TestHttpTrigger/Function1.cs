using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Xml;
using System.Net;
using System.Xml.Linq;
using System.Data;
using System;
using System.Globalization;
using System.Threading;
using System.Text;
using System.Linq;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace TestHttpTrigger
{
    public class Function1
    {
        public static DataTable dt_Name = new DataTable("BlobName");
        public static DataTable dt_Prop = new DataTable("BlobProperties");
        public static DataTable dt_Container = new DataTable("ContainerList");
        public static DataTable dt_EnumerationResult = new DataTable("EnumerationResult");
        public static string tableName = Environment.GetEnvironmentVariable("SQL_TABLE_NAME");
        public static string aa = "";
        public static String GetSqlConnection()
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = Environment.GetEnvironmentVariable("DATABASESERVERNAME");
            builder.UserID = Environment.GetEnvironmentVariable("DATABASEUSERNAME");
            builder.Password = Environment.GetEnvironmentVariable("DATABASEPASSWORD");
            builder.InitialCatalog = Environment.GetEnvironmentVariable("DATABASENAME");
            //SqlConnection connection = new SqlConnection(builder.ConnectionString);
            return builder.ConnectionString;
        }

        [FunctionName("Function1")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            //Get storage Account creds from request parameter

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            string storageAccountName = data["storagename"].ToString().Replace("\n", "").Trim().Replace(" ", "");
            string storageAccountKey = data["storagekey"].ToString().Replace("\n", "").Trim().Replace(" ", "");

            log.LogInformation($"{storageAccountName}:storagename");
            log.LogInformation($"{storageAccountKey}:storagekey");

            string responseMessage = string.IsNullOrEmpty(storageAccountName)
                ? "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."
                : $"Hello, Your storage name is : {storageAccountName} and key is {storageAccountKey}. This HTTP triggered function executed successfully.";


            Function1 func1 = new Function1();

            string containerURL = string.Format("https://{0}.blob.core.windows.net/?comp=list", storageAccountName);

            String sql_conn_string = GetSqlConnection();
            // Construct the URI. It will look like this:  https://myaccount.blob.core.windows.net/resource


            // Provide the appropriate payload, in this case null.
            //   we're not passing anything in.
            Byte[] requestPayload = null;

            try
            {
                //Get the List of container names present in the storage account
                List<string> containerList = await func1.GetContainerList(containerURL, storageAccountName, storageAccountKey, requestPayload, log);
                //log.LogInformation($"URI to get {containerName} data : {uri}");

                //Empty SQL table
                func1.TruncateSQLTable(sql_conn_string, log);
                log.LogInformation($"Truncated table {tableName}");

                foreach (var containerName in containerList)
                {
                    bool output = await new Function1().PerformOperations(containerName, storageAccountName, storageAccountKey, sql_conn_string, requestPayload, log);
                    if (output != true)
                    {
                        log.LogInformation($"No SQL operation performed for {containerName}");
                        continue;
                    }

                    /*while (dt_EnumerationResult.Rows.Count != 0 && !dt_EnumerationResult.Rows[0]["NextMarker"].ToString().Equals(string.Empty))
                    {
                        output = await new Function1().PerformOperations(containerName, storageAccountName, storageAccountKey, sql_conn_string, requestPayload, log, dt_EnumerationResult.Rows[0]["NextMarker"].ToString());
                        
                    }*/
                    log.LogInformation($"SQL operation performed for {containerName}");
                }
                log.LogInformation($"Executing Stored Procedure");
                func1.CallSP(sql_conn_string);
                log.LogInformation($"Executed Stored Procedure");
                responseMessage = "Operation Completed Successfully";
            }
            catch (Exception ex)
            {
                log.LogError($"Exception Occurred {ex}");
                responseMessage = "Operation Not Completed";
            }

            return new OkObjectResult(responseMessage);
        }
        public void CallSP(string sql_conn_string)
        {
            using (SqlConnection connection = new SqlConnection(sql_conn_string))
            {
                connection.Open();
                string truncCommand = string.Format("EXEC [the_night_owls].[sp_BlobsMetaData]");
                SqlCommand sp = new SqlCommand(truncCommand, connection);
                sp.CommandTimeout = 300;
                sp.ExecuteNonQuery();
            }

        }

        public async Task<bool> PerformOperations(string containerName, string storageAccountName, string storageAccountKey, string sql_conn_string, byte[] requestPayload, ILogger log, string marker = "")
        {
            string uri = string.Format("https://{0}.blob.core.windows.net/{1}?restype=container&comp=list&maxresults=3000&marker={2}", storageAccountName, containerName, marker);
            log.LogInformation($"CALLING URL: \n{uri}");

            // Instantiate the request message with a null payload.
            using (var httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, uri)
            { Content = (requestPayload == null) ? null : new ByteArrayContent(requestPayload) })
            {

                // Add the request headers for x-ms-date and x-ms-version.
                DateTime now = DateTime.UtcNow;
                httpRequestMessage.Headers.Add("x-ms-date", now.ToString("R", CultureInfo.InvariantCulture));
                httpRequestMessage.Headers.Add("x-ms-version", "2020-02-10");
                // If you need any additional headers, add them here before creating
                //   the authorization header. 

                // Add the authorization header.
                httpRequestMessage.Headers.Authorization = AzureStorageAuthenticationHelper.GetAuthorizationHeader(
                   storageAccountName, storageAccountKey, now, httpRequestMessage);

                // Send the request.
                using (HttpResponseMessage httpResponseMessage = await new HttpClient().SendAsync(httpRequestMessage, CancellationToken.None))
                {
                    // If successful (status code = 200), 
                    //   parse the XML response for the container names.
                    log.LogInformation($"Received response from API with status {httpResponseMessage.StatusCode}");
                    if (httpResponseMessage.StatusCode == HttpStatusCode.OK)
                    {
                        String xmlString = await httpResponseMessage.Content.ReadAsStringAsync();
                        XElement x = XElement.Parse(xmlString);
                        StringReader sr = new StringReader(x.ToString());

                        bool output = await convertIntoDataTable(sr, containerName, storageAccountName);
                        log.LogInformation($"Converted response into datatables at {DateTime.Now}");

                        if (output)
                        {
                            await InsertIntoSQLTableTwo(sql_conn_string, tableName);
                            log.LogInformation($"Inserted records into SQL table : StorageMetadata at {DateTime.Now}");
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public void TruncateSQLTable(string sql_conn_string, ILogger log)
        {

            using (SqlConnection connection = new SqlConnection(sql_conn_string))
            {
                connection.Open();
                string truncCommand = string.Format("TRUNCATE TABLE {0}", tableName);
                SqlCommand truncate = new SqlCommand(truncCommand, connection);
                truncate.CommandTimeout = 300;
                truncate.ExecuteNonQuery();
            }

        }

        public async Task<List<string>> GetContainerList(string containerURL, string storageAccountName, string storageAccountKey, byte[] requestPayload, ILogger log)
        {
            List<string> list = new List<string>();
            // Instantiate the request message with a null payload.
            using (var httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, containerURL)
            { Content = (requestPayload == null) ? null : new ByteArrayContent(requestPayload) })
            {

                // Add the request headers for x-ms-date and x-ms-version.
                DateTime now = DateTime.UtcNow;
                httpRequestMessage.Headers.Add("x-ms-date", now.ToString("R", CultureInfo.InvariantCulture));
                httpRequestMessage.Headers.Add("x-ms-version", "2020-02-10");
                // If you need any additional headers, add them here before creating
                //   the authorization header. 

                // Add the authorization header.
                httpRequestMessage.Headers.Authorization = AzureStorageAuthenticationHelper.GetAuthorizationHeader(
                   storageAccountName, storageAccountKey, now, httpRequestMessage);

                // Send the request.
                using (HttpResponseMessage httpResponseMessage = await new HttpClient().SendAsync(httpRequestMessage, CancellationToken.None))
                {
                    // If successful (status code = 200), 
                    //   parse the XML response for the container names.

                    if (httpResponseMessage.StatusCode == HttpStatusCode.OK)
                    {
                        String xmlString = await httpResponseMessage.Content.ReadAsStringAsync();
                        XElement x = XElement.Parse(xmlString);
                        StringReader sr = new StringReader(x.ToString());

                        DataSet ds = new DataSet();

                        ds.ReadXml(sr);
                        dt_Container = ds.Tables[2];
                        for (int i = 0; i < dt_Container.Rows.Count; i++)
                        {
                            list.Add(dt_Container.Rows[i]["Name"].ToString());
                        }
                    }
                }

            }

            return list;
        }

        public static async Task InsertIntoSQLTableTwo(string sql_conn_string, string tableName)
        {
            SqlConnection con = new SqlConnection(sql_conn_string);
            //create object of SqlBulkCopy which help to insert  
            SqlBulkCopy objbulk = new SqlBulkCopy(con);

            //assign Destination table name  
            objbulk.DestinationTableName = tableName;
            objbulk.ColumnMappings.Add("Blob_Path", "Blob_Path");
            objbulk.ColumnMappings.Add("Creation-Time", "Creation_Time");
            objbulk.ColumnMappings.Add("Content-Length", "Size");
            objbulk.ColumnMappings.Add("LastAccessTime", "Access_Time");
            objbulk.ColumnMappings.Add("Container_Name", "Container_Name");
            objbulk.ColumnMappings.Add("BlobType", "File_Type");
            objbulk.ColumnMappings.Add("Last-Modified", "Modified_Time");
            objbulk.ColumnMappings.Add("AccessTier", "Current_Tier");
            objbulk.ColumnMappings.Add("Scanned_Time", "Scanned_Time");
            con.Open();
            //insert bulk Records into DataBase.  
            objbulk.WriteToServer(dt_Prop);
            con.Close();
        }


        public static async Task<bool> convertIntoDataTable(StringReader sr, string containerName, string storageAccountName)
        {
            DataSet ds = new DataSet();

            ds.ReadXml(sr);
            bool enumResult = ds.Tables.Contains("EnumerationResults");
            bool blobName = ds.Tables.Contains("Blobs");
            bool blobProps = ds.Tables.Contains("Blob");
            if (enumResult != true || blobName != true || blobProps != true)
                return false;
            dt_EnumerationResult = ds.Tables[0];
            dt_Name = ds.Tables[2];

            dt_Prop = ds.Tables[3];
            dt_Prop.Columns.Add("Blob_Path");
            dt_Prop.Columns.Add("Container_Name");
            dt_Prop.Columns.Add("Scanned_Time");
            DateTime currentDateTime = DateTime.UtcNow;
            for (int i = 0; i < dt_Prop.Rows.Count; i++)
            {
                dt_Prop.Rows[i]["Blob_Path"] = string.Format("https://{0}.blob.core.windows.net/{1}/{2}", storageAccountName, containerName, dt_Name.Rows[i]["Name"]);
                dt_Prop.Rows[i]["Container_Name"] = containerName;
                dt_Prop.Rows[i]["LastAccessTime"] = DateTime.Parse(dt_Prop.Rows[i]["LastAccessTime"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                dt_Prop.Rows[i]["Creation-Time"] = DateTime.Parse(dt_Prop.Rows[i]["Creation-Time"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                dt_Prop.Rows[i]["Last-Modified"] = DateTime.Parse(dt_Prop.Rows[i]["Last-Modified"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                dt_Prop.Rows[i]["Scanned_Time"] = currentDateTime.ToString("yyyy-MM-dd HH:mm:ss"); //Fri, 09 Apr 2021 16:54:10 GMT
            }
            return true;
        }


    }

}


